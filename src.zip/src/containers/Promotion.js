import React, {Component} from 'react';

class Promotion extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false
    }
  }
  render() {

    return (<div className='promotion'>
      <div>
        <div onClick={this.props.showContent()}>
          <p className="interactiveText">Apply promotion code</p>
          <span>+</span>
        </div>

        <div className="togocontent">
          <div>Promo Code</div>
          <input type="text" onChange={this.props.promochage} value={this.props.value}/>
          <button onClick={this.props.applyPromo}>Apply</button>
        </div>

      </div>

    </div>)
  }
}
export default Promotion;
