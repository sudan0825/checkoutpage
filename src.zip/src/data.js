
let data=[
  {'name':'Sceptre 65" Class HD (2160P) 4K Curved LED TV (C650CV-U)',
  'image':'https://i5.walmartimages.com/asr/9720f86a-dd0f-44da-9d26-89628c6fe6ef_2.8f5449e471fc5c28c1dad518418efde4.jpeg?odnHeight=450&odnWidth=450&odnBg=FFFFFF',
  'quantity':2,
  'price':499},
  {'name':'VIZIO 70" Class D-Series 4K (2160P) Ultra HD HDR Smart LED TV (D70-F3) (2018 Model)',
  'image':'https://i5.walmartimages.com/asr/5bc8d959-7ff9-4d78-8193-8bfc291a6ac3_2.27c85b7991f468f79d18ed145d36c7c5.jpeg?odnHeight=450&odnWidth=450&odnBg=FFFFFF',
  'quantity':1,
  'price':699},
  {'name':'VIZIO 70" Class D-Series 4K (2160P) Ultra HD HDR Smart LED TV (D70-F3) (2018 Model)',
  'image':'https://i5.walmartimages.com/asr/5bc8d959-7ff9-4d78-8193-8bfc291a6ac3_2.27c85b7991f468f79d18ed145d36c7c5.jpeg?odnHeight=450&odnWidth=450&odnBg=FFFFFF',
  'quantity':1,
  'price':699}
]

export default data;
